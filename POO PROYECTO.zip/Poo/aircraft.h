#include <string>
#include <iostream>
#include <vector>
#include "flight.h"
#include <utility>
#include <map>
using namespace std;

#ifndef AIRCRAFT_H
#define AIRCRAFT_H

class Aircraft {
    protected:
        map<int,int> mapLocation;
        string type_aircraft;
        string brand;
        int model;
        int capacity;
        int maxium_speed;
        int Autonomy;
        int Year_of_manufacture;
        int state; 
        vector <Flight> vec_flights;
        int location;
        int id;
        bool flying;
        

    public:

        //Constructors
        Aircraft();
        Aircraft(const string& type_aircraft, const string& brand, int model,
             int capacity, int maxSpeed, int autonomy, int yearOfManufacture,
             int state,int location, int id, bool flying);
        //Sets, gets and adds
        string getBrand();
        int getModel();
        int getCapacity();
        int getMaxium_speed();
        int getAutonomy();
        int getYear_of_manufacture();
        int getState();
        int getvec_flights();
        int getMax_altitude();
        int getNum_engines();
        int getCategory();
        int getLocation();
        bool getFull_assigned();
        int getId();
        void setType(string type_aircraft);
        void setBrand(string brand);
        void setModel(int model);
        void setCapacity(int capacity);
        void setMaxium_speed(int maxium_speed);
        void setAutonomy(int Autonomy);
        void setYear_of_manufacture(int Year_of_manufacture);
        void setState(int state);
        void setMax_altitude(int max_altitude);
        void setNum_engines(int num_engines);
        void setCategory(int category);
        void setLocation(int location);
        void setFull_assigned(string full_assigned);
        void setId(int id);
        void setDeparture_date(string departure_date);
        void setArrival_date(string arrival_date);
        void addFlight(Flight flight);
        bool getFlying();
        string getType_aircraft();
        void setFlying(bool flying);
        void addVec_flights(Flight flights);

        //Virtual functions that are used in the derived classes, and are used to print the information of the aircraft, and to change the state of the aircraft
        virtual void landing();
        virtual void taking_off();

        //Prints the information of the aircraft, the location, id and if it is flying or not
        void notify_location(int id, int altitude, bool flying);
        //Recieve a map with the location of all the aircrafts that are flying, and updates the map with the location of the aircraft
        void update(map<int,int> mapLocation_atc);

        //Prints information of the aircraft
        void printCommonDetails();
        void printLocation();
        void printVec_flights() ;


        //Recieve a bool that is the permission to take off or land, and updates the state of the aircraft
        void updatePermission(bool permission);
        

        

};

#endif
