#include <iostream>
#include <string.h>
#include <vector>
#include "passenger.h"
#include "passenger.cpp"
#include "crewmate.h"
#include "crewmate.cpp"
#include "flight.h"
#include "aircraft.h"
#include "aircraft.cpp"
#include "airplane.cpp"
#include "people.h"
#include "people.cpp"
#include "jet.h"
#include "jet.cpp"
#include "helicopter.h"
#include "helicopter.cpp"
#include "aircraftFactory.h"
#include "aircraftFactory.cpp"
#include "AirTrafficControler.h"
#include "AirTrafficControler.cpp"
#include "gate.h"
#include "gate.cpp"
#include "flight.h"
#include "flight.cpp"
#include "Airline.h"
#include "airline.cpp"
#include "airport.cpp"
#include "airport.h"



using namespace std;

int main() {
    Aircraft* airplane = AircraftFactory::createAirplane("Boeing", 747, 500, 1000, 2000, 2010,
        1, 10000, 4, 1, 1, 12, false, 100, 100);

    Aircraft* helicopter = AircraftFactory::createHelicopter("Sikorsky", 123, 10, 150, 500, 2022,
        1, 15000, 13, true, 5, 1000, 1);

    Aircraft* jet = AircraftFactory::createJet("Gulfstream", 550, 12, 600, 2500, 2019,
            1, 45000, 14, true, "Owner1",
            { "Service1", "Service2" }, { "Destiny1", "Destiny2" });

    Aircraft* airplane2 = AircraftFactory::createAirplane("Boeing", 747, 500, 1000, 2000, 2010,
        1, 10000, 4, 1, 1, 132, false, 100, 100);

    vector<Aircraft*> aircrafts = { airplane, helicopter, jet, airplane2 };

    vector <Gate*> totalgates;
    Gate* gate1 = new Gate(1,true,"Seccion A","12:45");
    Gate* gate2 = new Gate(2,true,"Seccion A","09:45");
    Gate* gate3 = new Gate(3,true,"Seccion B","13:30");
    Gate* gate4 = new Gate(4,true,"Seccion C","18:15");
    Gate* gate5 = new Gate(5,true,"Seccion D","14:00");

    totalgates.push_back(gate1);
    totalgates.push_back(gate2);
    totalgates.push_back(gate3);
    totalgates.push_back(gate4);
    totalgates.push_back(gate5);

    vector <Flight*> Destination;
    vector <Passenger> fligh_passengers;
    vector <Passenger> fligh_passengers2;
    vector <Passenger> fligh_passengers3;
    vector <Passenger> fligh_passengers4;
    vector <Passenger> fligh_passengers5;
    vector <Passenger> fligh_passengers6;
    vector <Passenger> fligh_passengers7;
    Flight* flight4813 = new Flight(4813,"Bogota",1,"12/10/2023","12/10/2023","Cali",fligh_passengers,false);
    Flight* flight4912 = new Flight(4912,"Cali",10,"13/10/2023","13/10/2023","Madrid",fligh_passengers2,false);
    Flight* flight5513 = new Flight(5513,"Bogota",4,"14/10/2023","14/10/2023","Cali",fligh_passengers3,false);
    Flight* flight6517 = new Flight(6517,"Maimi",8,"16/10/2023","16/10/2023","Cali",fligh_passengers4,false);
    Flight* flight3434 = new Flight(3434,"Miami",20,"15/10/2023","16/10/2023","Cali",fligh_passengers5,false);
    Flight* flight1626 = new Flight(1626,"Medellin",8,"15/10/2023","16/10/2023","Cali",fligh_passengers6,false);
    Flight* flight4814 = new Flight(4814,"Cali",2,"03/11/2023","03/11/2023","Medellin",fligh_passengers7,false);

    Destination.push_back(flight4813);
    Destination.push_back(flight4912);
    Destination.push_back(flight5513);
    Destination.push_back(flight6517);
    Destination.push_back(flight3434);
    Destination.push_back(flight1626);
    Destination.push_back(flight4814);
    Airport *airport = new Airport("Aeropuerto Alfonso Bonilla Aragón");
    vector<string> Destinations = {"Bogota", "Medellin", "Miami"};

    airport->createAirTrafficControler();
    airport->createAirline();
    airport->setVecAircrafts(aircrafts);
    airport->setVecGates(totalgates);
    airport->setVecFlights(Destination);
    airport->menu(Destinations);

    
    

    return 0;
}





