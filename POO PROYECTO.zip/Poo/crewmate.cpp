#include "crewmate.h"

Crewmate::Crewmate(const std::string& name, int id, int number, const std::string& birth, const std::string& gender, const std::string& email,const std::string charge, int years_experience, int daily_hours)
    : People(name, id, number, birth, gender, email){
        this->charge = charge;
        this-> years_experience = years_experience;
        this->daily_hours = daily_hours;
}

string Crewmate::getCharge(){
    return charge;
}

int Crewmate::getYearsExperience(){
    return years_experience;
}

int Crewmate::getDailyHours(){
    return daily_hours;
}

void Crewmate::setCharge(string charge){
    this->charge = charge;
}

void Crewmate::setYearsExperience(int years){
    this->years_experience = years;
}

void Crewmate::setDailyHours(int hours){
    this->daily_hours = hours;
}

