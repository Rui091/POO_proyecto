#include "gate.h"

Gate::Gate(){
    id = 0;
    available = true;
    location = "";
    boardingHour = "";
}
Gate::Gate(int id, bool availible, string location, string boardingHour){
    this->id = id;
    this->available = availible;
    this->location = location;
    this->boardingHour = boardingHour;
}

int Gate::getId(){
    return this->id;
}

int Gate::getFlightid(){
    return this->flight.getNumberFlight();
}

bool Gate::getAvailable(){
    return this->available;
}

string Gate::getLocation(){
    return this->location;
}


string Gate::getBoardingHour(){
    return this->boardingHour;
}

void Gate::setId(int id){
    this->id = id;
}

void Gate::setAvalible(bool available){
    this->available = available;
}

void Gate::setLocation(string location){
    this->location = location;
}

void Gate::setBoardingHour(string boardingHour){
    this->boardingHour = boardingHour;
}

void Gate::setFlight(Flight flight){
    this->flight = flight;
}

Flight Gate::getFlight(){
    return this->flight;
}

void Gate::addRecordedFlight(Flight flight){
    this->recordedFlights.push_back(flight);
}
