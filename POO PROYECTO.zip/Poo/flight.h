#include <iostream>
#include <string>
#include <vector>
#include "passenger.h"
#include "crewmate.h"


#ifndef FLIGHT_H
#define FLIGHT_H

using namespace std;

class Flight {
    private:
        int numberFlight;
        string Destiny;
        int numberPassengers;
        string departureDate;
        string arrivalDate;
        string Origen; 
        int seats;
        bool asignado;
        vector<Passenger> passengers;
        vector<Crewmate> crewmates;
        bool gateAsigned;
        
    public:
    //Constructor para vuelo, recibe el numero de vuelo, el destino, el numero de pasajeros, la fecha de salida, la fecha de llegada y el origen
        Flight();
        Flight(int numberFlight, string Destiny, int numberPassengers, string departureDate, string arrivalDate, string Origen, vector <Passenger>flight_passengers,bool gateAsigned);
    //getters, setters y adds
        int getNumberFlight();
        int getSeats();
        bool getAsignado();
        void setAsignado(bool asignado);
        void setgate(bool gateAsigned1);
        bool getGateAsigned();
        string getDestiny();
        int getNumberPassengers();
        string getDepartureDate();
        string getArrivalDate();
        string getOrigen();
        void setNumberFlight(int numberFlight);
        void setDestiny(string Destiny);
        void setNumberPassengers(int numberPassengers);
        void setDepartureDate(string departureDate);
        void setArrivalDate(string arrivalDate);
        void setOrigen(string Origen);
        void addPassenger(Passenger passenger);
        vector<Passenger> getPassengers();
        void addCrewmates();
    //Metodo para imprimir la informacion del vuelo
        void printInfo();
        

        
};

#endif