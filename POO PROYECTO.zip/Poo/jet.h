#include "aircraft.h"
#include <vector>
#include <string>

using namespace std;

#ifndef JET_H
#define JET_H

class Jet:public Aircraft{
    private:
        string owner;
        vector <string> services;
        vector <string> destinies; 
    public:
    //Constructor de jet
        Jet(const string& brand, int model, int capacity,
        int maxSpeed, int autonomy, int yearOfManufacture,
        int state,
        int location, int id,
        bool flying,
        const string& owner, const vector<string>& services,
        const vector<string>& destinies)
        : Aircraft("Jet", brand, model, capacity, maxSpeed, autonomy,
                   yearOfManufacture, state,location,
                     id, flying),
          owner(owner),
          services(services),
          destinies(destinies) {}
    //getters y setters
        string getOwner();
        vector <string> getServices();
        vector <string> getDestinies();
        void setOwner(string owner);
        void addService(string service);
        void addDestiny(string destiny);
    //Metodos de la clase jet, que se encargan aterrizar y despegar, estos metodos son override de los metodos de la clase aeronave
        void landing() override;
        void taking_off() override;
        


};

#endif