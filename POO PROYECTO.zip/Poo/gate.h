#include <string>
#include "flight.h"

using namespace std;

#ifndef GATE_H
#define GATE_H

class Gate{
    private:
        int id;
        bool available;
        string location;
        string boardingHour;
        Flight flight;
        vector<Flight> recordedFlights;
    public:
    //constructor para puerta, recibe el id, si esta disponible, la ubicacion y la hora de abordaje
        Gate();
        Gate(int id, bool availible, string location, string boardingHour);
    //getters, setters y adds
        void setFlight(Flight flight);
        Flight getFlight();
        int getFlightid();
        void addRecordedFlight(Flight flight);
        vector<Flight> getRecordedFlights();
        int getId();
        bool getAvailable();
        string getLocation();
        string getBoardingHour();
        void setId(int id);
        void setAvalible(bool available);
        void setLocation(string location);
        void setBoardingHour(string boardingHour);
};




#endif