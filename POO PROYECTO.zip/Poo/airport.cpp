#include "airport.h"


Airport::Airport(string name){
    this->name = name;
    this->atc = nullptr;
    flights = {};
    aircrafts = {};
    gates = {};
    airlines = {};
}

void Airport::createAircraft(){
    int option;
    string brand;
    int model;
    int capacity;
    int maxium_speed;
    int Autonomy;
    int Year_of_manufacture;
    int state; 
    int max_altitude;
    int num_engines;
    int category;
    int location;
    int id;
    bool flying;
    cout << "1. Jet" << endl;
    cout << "2. Airplane" << endl;
    cout << "3. Helicopter" << endl;
    cout << "Choose an option: ";
    cin >> option;
    cout << "Enter the following information:" << endl;
    cout << "Brand: ";
    cin >> brand;
    cout << "Model: ";
    cin >> model;
    cout << "Capacity: ";
    cin >> capacity;
    cout << "Maxium speed: ";
    cin >> maxium_speed;
    cout << "Autonomy: ";
    cin >> Autonomy;
    cout << "Year of manufacture: ";
    cin >> Year_of_manufacture;
    cout << "State: ";
    cin >> state;
    cout << "Location: ";
    cin >> location;
    cout << "Id: ";
    cin >> id;
    cout << "Flying: ";
    cin >> flying;

    if(option == 1){
        cout << "Owner: ";
        string owner;
        cin >> owner;
        Aircraft* jet = AircraftFactory::createJet(brand, model, capacity, maxium_speed, Autonomy, Year_of_manufacture, state, location, id, flying, owner, {}, {});
        aircrafts.push_back(jet);
    }
    else if(option == 2){
        cout << "Seats: ";
        int seats;
        cin >> seats;
        cout << "Available seats: ";
        int available_seats;
        cin >> available_seats;
        cout << "Max altitude: ";
        cin >> max_altitude;
        cout << "Number of engines: ";
        cin >> num_engines;
        cout << "Category: ";
        cin >> category;
        Aircraft* airplane = AircraftFactory::createAirplane(brand, model, capacity, maxium_speed, Autonomy, Year_of_manufacture, state, max_altitude, num_engines, category, location, id, flying, seats, available_seats);
        aircrafts.push_back(airplane);
    }
    else if(option == 3){
        cout << "Rotors: ";
        int rotors;
        cin >> rotors;
        cout << "Elevation capacity: ";
        int elevation_capacity;
        cin >> elevation_capacity;
        cout << "Use type: ";
        int use_type;
        cin >> use_type;
        Aircraft* helicopter = AircraftFactory::createHelicopter(brand, model, capacity, maxium_speed, Autonomy, Year_of_manufacture, state, location, id, flying, rotors, elevation_capacity, use_type);
        aircrafts.push_back(helicopter);
    }
}

void Airport::createAirline(){
    string name;
    cout << "Enter the name of the airline: ";
    cin >> name;
    Airline* airline = new Airline(name);
    airlines.push_back(airline);
}

void Airport::createGate(){
    int number;
    bool available;
    string location;
    string boardingHour;
    cout << "Enter the ID of the gate: ";
    cin >> number;
    cout << "Enter the availability of the gate: ";
    cin >> available;
    cout << "Enter the location of the gate: ";
    cin >> location;
    cout << "Enter the boarding hour of the gate: ";
    cin >> boardingHour;

    Gate* gate = new Gate(number, available, location, boardingHour);
    gates.push_back(gate);

}

void Airport::createAirTrafficControler(){
    AirTrafficControler* atc= new AirTrafficControler();
    this->atc = atc;
}

void Airport::addAircraft(Aircraft *aircraft){
    this->aircrafts.push_back(aircraft);
}

void Airport::addFlight(Flight *flight){
    this->flights.push_back(flight);
}

void Airport::addAirline(Airline *airline){
    this->airlines.push_back(airline);
}

string Airport::getName(){
    return this->name;
}

void Airport::setName(string name){
    this->name = name;
}

vector<Flight*> Airport::getFlights(){
    return this->flights;
}

vector<Aircraft*> Airport::getAircrafts(){
    return this->aircrafts;
}

vector<Gate*> Airport::getGates(){
    return this->gates;
}

vector<Airline*> Airport::getAirlines(){
    return this->airlines;
}

AirTrafficControler* Airport::getAirTrafficControler(){
    return this->atc;
}

void Airport::setVecGates(vector<Gate*> gates){
    this->gates = gates;
}

void Airport::setVecAircrafts(vector<Aircraft*> aircrafts){
    this->aircrafts = aircrafts;
}

void Airport::setVecFlights(vector<Flight*> flights){
    this->flights = flights;
}

void Airport::menu(vector<string> Destination){
    int select, city_selected, flight_selected, current_flight;
    bool available_flight = false;
    string password_control_tower = "1234";
    string password;
    string name, birth, gender, email, medicalinfo,nationality;
    int id, number, numbags,desicion;
    atc->setVecGates(gates);
    atc->setVecAircrafts(aircrafts);
    cout<<"----------------------------------------------------------- \n";
    printf("                  Select one option                        \n");
    printf("                     1. Start                              \n");
    printf("                     2. Exit                               \n");
    cout<<"----------------------------------------------------------- \n";
    cin >> desicion;
    while(desicion!=2){
        printf("-----------------------------------------------------------\n");
        cout << "              Welcome to " << this->name << endl;
        printf("                  Select one option                        \n");
        printf("                     1. Employee                           \n");
        printf("                     2. Traveler                           \n");
        printf("-----------------------------------------------------------\n");
        scanf("%d", &select);

        if(select == 1){
            printf("-----------------------------------------------------------\n");
            printf("                  Select one option                        \n");
            printf("                     1. Torre de control                   \n");
            printf("                     2. Aerolinea                          \n");
            printf("-----------------------------------------------------------\n");
            int sel;
            int sel2;
            cin >> sel2;
            if(sel2==1){
                printf("-----------------------------------------------------------\n");
                printf("Please enter the password to access the control tower\n");
                printf("-----------------------------------------------------------\n");
                cin >> password;
                if(password==password_control_tower){
                    printf("                  Select one option                        \n");
                    printf("                    1. Notify                              \n");
                    printf("                    2. Assigned gate                       \n");
                    printf("                    3. Permission                          \n");
                    printf("-----------------------------------------------------------\n");
                    cin >> sel;
                    if(sel==1){
                        atc->notify();
                        printf("-----------------------------------------------------------\n");
                        printf("The location of the aircrafts has been updated\n");
                        printf("-----------------------------------------------------------\n");
                        for (int i=0;i<atc->getAircrafts().size();i++){
                            if(atc->getAircrafts()[i]->getFlying()==true){
                                cout<<"Aircraft "<<atc->getAircrafts()[i]->getId()<<" has this locations"<<endl;
                                atc->getAircrafts()[i]->printLocation();
                                cout<<endl;
                            }
                        }
                    }

                    else if(sel==2){
                        int flight_selected;
                        printf("-----------------------------------------------------------\n");
                        for(int j = 0; j < flights.size(); j++){
                            if(flights[j]->getGateAsigned() == false){
                                flights[j]->printInfo();
                                printf("-----------------------------------------------------------\n");
                                }
                            }
                        printf("-----------------------------------------------------------\n");
                        printf("Please select the flight you want to assign a gate\n");
                        cin >> flight_selected;
                        for(int i = 0;i < flights.size();++i){
                            if(flights[i]->getNumberFlight() == flight_selected && flights[i]->getGateAsigned() == false){
                                atc->assingGate(*flights[i]);
                                flights[i]->setgate(true);
                                printf("-----------------------------------------------------------\n");
                                printf("The gate has been assigned\n");
                                printf("-----------------------------------------------------------\n");
                            }
        
                        }

                        }
                    else{
                        int id;
                        int permission;
                        printf("-----------------------------------------------------------\n");
                        for(int p=0;p<atc->getAircrafts().size();p++){
                            cout<<"Aircraft "<<atc->getAircrafts()[p]->getId()<<endl;
                        }
                        printf("Please enter the id of the aircraft\n");
                        cin >> id;
                        printf("-----------------------------------------------------------\n");
                        try{
                            printf("Please enter the permission\n");
                            cin >> permission;
                            printf("-----------------------------------------------------------\n");
                            if(permission != 0 && permission != 1){
                                throw invalid_argument("Invalid permission");
                            }
                            else{
                                atc->permisson(permission,id);
                            }
                            
                        }
                        catch(const invalid_argument& e){
                            cout << e.what() << endl;
                        }
                        if(permission == 0 || permission == 1){
                            printf("-----------------------------------------------------------\n");
                            printf("The permission has been updated\n");
                            printf("-----------------------------------------------------------\n");
                        }
                    }

                    

                    }
                }
            
            else if(sel2==2){
        

                printf("-----------------------------------------------------------\n");
                printf("                  Select one option                        \n");
                printf("                    1. Asignar Avion a vuelo               \n");
                printf("-----------------------------------------------------------\n");

                cin >> sel;
                if(sel==1){
                    airlines[0]->assignAircraftToFlight(atc->getAircrafts(),flights);
                    printf("-----------------------------------------------------------\n");
                }

                }
        
            }

        else{

            
            printf("--------------------------------------------------------\n");
            printf("    Please provide the following information     \n");
            Passenger* persona1 = new Passenger(); //agrega un pasajero a traves de la consola
            printf("---------------------------------------------------------\n");
            printf("         Select your destiantion:        \n");
            for(int city = 0; city < Destination.size(); ++city){ // permite mostrar los destinos disponibles
                int actual_city = city+1;
                printf("%d: %s\n",actual_city,Destination[city].c_str());
            }
            scanf("%d", &city_selected); //Muestra todos los vuelos disponibles para el destino que escogimmos
            for(int j= 0; j < flights.size(); j++){
                if(flights[j]->getDestiny() == Destination[city_selected - 1].c_str()){
                    flights[j]->printInfo();
                    printf("\n");
                }
            }
            available_flight = false;
            while(available_flight == false){
                printf("Type the number of the flight that you'd like to choose\n");
                scanf("%d", &flight_selected); // agrega el pasajero al vuelo seleccionado
                for(int j= 0; j < flights.size(); j++){
                    if(flights[j]->getNumberFlight() == flight_selected){
                        if(flights[j]->getSeats() < 1){ // verifica si hay sillas disponibles antes de agregar al avion
                            printf("-----------------------------------------------------------\n");
                            printf("-    there are not seats availables in the flight %d      -\n",flight_selected);
                            printf("-                Please select a different flight         -\n");
                            printf("-----------------------------------------------------------\n\n");
                        }
                        else{
                            flights[j]->addPassenger(*persona1); // agrega al vuelo si hay asientos disponibles
                            current_flight = j;
                            available_flight = true;
                        }
                    }
                }
            }
            printf("----------------------------\n");
            printf("You have booked successfully\n");
            flights[current_flight]->printInfo(); //imprime el vuelo en el cual pudo reservar

            }
            cout<<"----------------------------------------------------------- \n";
            printf("                  Select one option                        \n");
            printf("                     1. Start                              \n");
            printf("                     2. Exit                               \n");
            cout<<"----------------------------------------------------------- \n";
            cin >> desicion;
        }
}


