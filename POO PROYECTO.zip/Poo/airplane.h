#include "aircraft.h"


using namespace std;

#ifndef AIRPLANE_H
#define AIRPLANE_H

class Airplane:public Aircraft{
    private:
        int max_altitude;
        int num_engines;
        int category;
        int seats;
        int avalibleSeats;

    public:
    //Constructor para avion, de esta forma facilitar el factory
        Airplane();
         Airplane(const string& brand, int model, int capacity,
             int maxSpeed, int autonomy, int yearOfManufacture,
             int state, int maxAltitude, int numEngines, int category,
             int location, int id,
             bool flying, int seats, int availableSeats)
        : Aircraft("Airplane", brand, model, capacity, maxSpeed, autonomy,
                   yearOfManufacture, state,location,
                     id, flying),
          max_altitude(maxAltitude),
          num_engines(numEngines), category(category),
          seats(seats), avalibleSeats(availableSeats) {}
        ~Airplane();
        //getters y setters
        int getNum_engines() ;
        int getCategory() ;
        int getMax_altitude() ;
        void setMax_altitude(int max_altitude);
        void setNum_engines(int num_engines);
        void setCategory(int category);
        void setSeats(int seats);
        int getSeats();
        int getAvalibleSeats();
        void setAvalibleSeats(int avalibleSeats);

        //Metodos de la clase avion que hereda de la clase aircraft, se encargan de despegar y aterrizar
        void landing() override;
        void taking_off() override;

};

#endif
