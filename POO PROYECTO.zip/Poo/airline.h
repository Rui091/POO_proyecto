#include <string>
#include <iostream>
#include <vector>
#include "aircraft.h"
#include "flight.h"
#include "jet.h"
#include "airplane.h"
#include "helicopter.h"
#include <map>
using namespace std;

#ifndef AIRLINE_H
#define AIRLINE_H

/**
 * @brief Clase que representa una aerolínea.
 */
class Airline {
private:
    string name;                  ///< Nombre de la aerolínea.
    map<int, Aircraft> mapa;      ///< Mapa que almacena las aeronaves de la aerolínea.
    vector<int> vec_id;           ///< Vector que almacena los identificadores de las aeronaves.

public:
    /**
     * @brief Constructor por defecto.
     */
    Airline();

    /**
     * @brief Constructor con parámetros.
     * @param name Nombre de la aerolínea.
     */
    Airline(string name);

    /**
     * @brief Obtiene el nombre de la aerolínea.
     * @return Nombre de la aerolínea.
     */
    string getName();

    /**
     * @brief Establece el nombre de la aerolínea.
     * @param name Nuevo nombre de la aerolínea.
     */
    void setName(string name);

    /**
     * @brief Agrega una aeronave a la aerolínea.
     * @param aircraft Aeronave a agregar.
     */
    void addAircraft(Aircraft aircraft);

    /**
     * @brief Asigna aeronaves a vuelos.
     * @param aircrafts Vector de punteros a aeronaves.
     * @param flights Vector de punteros a vuelos.
     */
    //Recibe dos vectores de punteros, uno de aeronaves y otro de vuelos, 
    //y asigna la cantidad maxima de vuelos a cada aeronave, 
    //osea cada aeronave deberia tener idealmente 3 vuelos, en caso de que hay mas vuelos que cantidad de aviones con cupos disponibles, los vuelos restantes quedan en stand by.
    void assignAircraftToFlight(vector<Aircraft*> aircrafts, vector<Flight*> flights);
};

#endif