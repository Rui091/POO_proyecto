#include "aircraft.h"


using namespace std;

#ifndef HELICOPTER_H
#define HELICOPTER_H


class Helicopter: public Aircraft{
    private:
        int rotors;
        int elevationCapacity;
        int useType;
    public:
    //Constructor de helicoptero
        Helicopter(const string& brand, int model, int capacity,
               int maxSpeed, int autonomy, int yearOfManufacture,
               int state,
               int location, int id,
               bool flying, int rotors, int elevationCapacity, int useType)
        : Aircraft("Helicopter", brand, model, capacity, maxSpeed, autonomy,
                   yearOfManufacture, state,location, id, flying),
          rotors(rotors),
          elevationCapacity(elevationCapacity),
          useType(useType) {}
        ~Helicopter();
    //getters y setters
        int getRotors();
        int getElevationCapacity();
        int getUseType();
        void setRotors(int rotors);
        void setElevationCapacity(int elevationCapacity);
        void setUseType(int useType);
    //Metodos de la clase helicoptero, que se encargan aterrizar y despegar, estos metodos son override de los metodos de la clase aeronave
        void landing() override;
        void taking_off() override;

};

#endif