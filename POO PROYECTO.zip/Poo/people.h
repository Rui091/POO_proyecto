#include <string>
#include <iostream>

using namespace std;

#ifndef PEOPLE_H
#define PEOPLE_H

class People{
    protected:
        string name;
        int id;
        int number;
        string birth; 
        string gender;
        string email;
    public:
    //constructores de people
        People();
        People(string name, int id, int number, string birth, string gender, string email);
    //getters y setters
        string getName();
        int getId();
        int getNumber();
        string getBirth();
        string getGender();
        string getEmail();
        void setName(string name);
        void setId(int id);
        void setNumber(int number);
        void setBirth(string birth);
        void setEmail(string email);
        void setGender(string gender);
};




#endif