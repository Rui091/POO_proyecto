#include "passenger.h"

Passenger::Passenger(){
    cout << "Name: ";
    cin.ignore();
    getline(cin, name);
    this->name = name;
    cout << "Birth: ";
    getline(cin, birth);
    this->birth = birth;
    cout << "Gender: ";
    getline(cin, gender);
    this->gender = gender;
    cout << "ID: ";
    cin >> id;
    this->id = id;
    cout << "Email: ";
    cin.ignore();
    getline(cin, email);
    this->email = email;
    cout << "Medical Information: ";
    getline(cin, medical_info);
    this->medical_info = medical_info;
    cout << "Nationality: ";
    getline(cin, nationality);
    this->nationality = nationality;
    cout << "Phone Number: ";
    cin >> number;
    this->number = number;
    cout << "Number of Bags: ";
    cin >> numBags;
    this->numBags = numBags;
}

Passenger::Passenger(const std::string& name, int id, int number, const std::string& birth, const std::string& gender, const std::string& email,
                     int numBags, const std::string& medical_info, const std::string& nacionality)
    : People(name, id, number, birth, gender, email){
    this->numBags = numBags;
    this-> medical_info = medical_info;
    this -> nationality = nacionality;
}

void Passenger::printInfo(){
    cout << "Name: " << this->name << endl;
    cout << "ID: " << this->id << endl;
    cout << "Phone number : " << this->number << endl;
    cout << "Birth: " << this->birth << endl;
    cout << "Gender: " << this->gender << endl;
    cout << "Email: " << this->email << endl;
    cout << "Number of bags: " << this->numBags << endl;
    cout << "medical information: " << this->medical_info << endl;
    cout << "Nationality: " << this->nationality << endl;
}




int Passenger::getNumBags(){
    return numBags;

}

string Passenger::getMedicalInfo(){
    return medical_info;
}

string Passenger::getNationality(){
    return nationality;
}
void Passenger::setNumBags(int numBags){
    this->numBags = numBags;
}

void Passenger::setMedicalInfo(string medical_info){
    this->medical_info = medical_info;
}

void Passenger::setNacionality(string nationality){
    this->nationality = nationality;
}
