#include "aircraftFactory.h"
#include "aircraft.h"
#include "airplane.h"
#include "helicopter.h"



Aircraft* AircraftFactory::createAirplane(const string& brand, int model, int capacity,
             int maxSpeed, int autonomy, int yearOfManufacture,
             int state, int maxAltitude, int numEngines, int category,
             int location, int id,
             bool flying, int seats, int availableSeats){
    return new Airplane(brand, model, capacity, maxSpeed, autonomy, yearOfManufacture,
        state, maxAltitude, numEngines, category, location, id,
        flying, seats, availableSeats);
}

Aircraft* AircraftFactory::createHelicopter(const std::string& brand, int model, int capacity,
    int maxSpeed, int autonomy, int yearOfManufacture, int state , int location,
    int id, bool flying,int rotors, int elevationCapacity, int useType) {
    return new Helicopter(brand, model, capacity, maxSpeed, autonomy, yearOfManufacture,
        state,location, id, flying,  rotors, elevationCapacity, useType);
}

Aircraft* AircraftFactory::createJet(const string& brand, int model, int capacity,
        int maxSpeed, int autonomy, int yearOfManufacture, int state, int location, 
        int id, bool flying,const string& owner, const vector<string>& services,
        const vector<string>& destinies) {
    return new Jet(brand, model, capacity, maxSpeed, autonomy, yearOfManufacture,
        state, location, id, flying, owner, services, destinies);
}

