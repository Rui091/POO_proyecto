#include "AirTrafficControler.h"


AirTrafficControler::AirTrafficControler(){
    aircrafts = {};
    gates = {};
    airCraftLocations = {};
}

AirTrafficControler::AirTrafficControler(vector<Aircraft*> aircrafts, vector<Gate*> gates){
    this->aircrafts = aircrafts;
    this->gates = gates;
}

void AirTrafficControler::setVecGates(vector<Gate*> gates){
    this->gates = gates;
}

vector<Aircraft*> AirTrafficControler::getAircrafts(){
    return this->aircrafts;
}

vector<Gate*> AirTrafficControler::getGates(){
    return this->gates;
}

void AirTrafficControler::addAircraft(Aircraft *aircraft){
    this->aircrafts.push_back(aircraft);
}

void AirTrafficControler::removeAircraft(int id) {
    for (int i = aircrafts.size() - 1; i >= 0; --i) {
        if (aircrafts[i]->getId() == id) {
            delete aircrafts[i]; 
            aircrafts.erase(aircrafts.begin() + i); 
        }
    }
}

void AirTrafficControler::permisson(bool permisson, int id){
    int i=0;
    bool found=false;
    while(i<aircrafts.size() && found==false){
        if(aircrafts[i]->getId()==id){
            aircrafts[i]->updatePermission(permisson);
            found=true;
            
        }
        ++i;
    }
    if (found==false){
        cout<<"Aircraft not found"<<endl;
    }
    if(permisson==true){
        if(aircrafts[i-1]->getFlying()==false){
            this->removeAircraft(id);
            for(int j=0;j<this->gates.size();++j){
                if(gates[j]->getFlightid()==id){
                    gates[j]->setAvalible(true);
                    }
                }
            }
        }
    

}

void AirTrafficControler::assingGate(Flight &flight){
    int selectedGate;
    for(int i=0;i<this->gates.size();++i){
        if(gates[i]->getAvailable()==true){
            cout<<"Choose a gate"<<endl;
            cout<<i+1<<"."<<" Gate "<<gates[i]->getId()<<" is available"<<endl;
        }
    }
    cin>>selectedGate;
    gates[selectedGate-1]->setFlight(flight);
    gates[selectedGate-1]->setAvalible(false);
    gates[selectedGate-1]->addRecordedFlight(flight);
}

void AirTrafficControler::notify() {
    airCraftLocations.clear();
    for (int i = 0; i < aircrafts.size(); ++i) {
        if (aircrafts[i]->getFlying()) { 
            airCraftLocations[aircrafts[i]->getId()] = aircrafts[i]->getLocation();

        }
    }
     

    for (int j = 0; j < aircrafts.size(); ++j) {
        if (aircrafts[j]->getFlying()) { 
            aircrafts[j]->update(airCraftLocations);
        }
    }
}

void AirTrafficControler::setVecAircrafts(vector<Aircraft*> aircrafts){
    this->aircrafts = aircrafts;
}

