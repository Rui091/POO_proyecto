#include "airline.h"

Airline::Airline(){
    name = "";
    

}

Airline::Airline(string name){
    this->name = name;
    
    
    
}

string Airline::getName(){
    return name;
}




void Airline::setName(string name){
    this->name = name;
}




void Airline::assignAircraftToFlight(vector<Aircraft*> aircrafts, vector<Flight*> flights){
    cout<<"Aircrafts"<<endl;
    for(int i=0;i< flights.size();++i){
        if(flights[i]->getOrigen() == "Cali" ){
            int j=0;
            while(j<aircrafts.size() && flights[i]->getAsignado()==false){
                if(aircrafts[j]->getType_aircraft()=="Airplane" && aircrafts[j]->getFlying()==false && aircrafts[j]->getvec_flights()<3 ){
                    aircrafts[j]->addFlight(*flights[i]);
                    flights[i]->setAsignado(true);
                    if (mapa.find(aircrafts[j]->getId()) == mapa.end()) {
                        mapa[aircrafts[j]->getId()] = (*aircrafts[j]);
                        vec_id.push_back(aircrafts[j]->getId());
                        }
                    else{
                        mapa[aircrafts[j]->getId()] = (*aircrafts[j]);
                    }
                    
                    }
                    ++j;
                }
            }
        }
    for(int x=0;x<vec_id.size();++x){
        mapa[vec_id[x]].printVec_flights();

        }
    
    
}