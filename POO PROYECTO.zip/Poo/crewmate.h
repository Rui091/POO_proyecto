#include "people.h"

#ifndef CREWMATE_H
#define CREWMATE_H  



class Crewmate:public People{
    private:
        string charge;
        int years_experience;
        int daily_hours;
    public:
    //Constructor para tripulante
        Crewmate(const std::string& name, int id, int number, const std::string& birth, const std::string& gender, const std::string& email,const std::string charge, int years_experience, int daily_hours);
    //getters y setters
        string getCharge();
        int getYearsExperience();
        int getDailyHours();    
        void setCharge(string charge);
        void setYearsExperience(int years);
        void setDailyHours(int hours);
        
};

#endif