#include "airplane.h"

Airplane::Airplane(){
    max_altitude = 0;
    num_engines = 0;
    category = 0;
    seats = 0;
    avalibleSeats = 0;
}

Airplane::~Airplane(){

}
int Airplane::getNum_engines(){
    return num_engines;
}

int Airplane::getCategory(){
    return category;
}

int Airplane::getSeats(){
    return seats;
}

int Airplane::getAvalibleSeats(){
    return avalibleSeats;
}

void Airplane::setMax_altitude(int max_altitude){
    this->max_altitude = max_altitude;
}

void Airplane::setNum_engines(int num_engines){
    this->num_engines = num_engines;
}

void Airplane::setCategory(int category){
    this->category = category;
}

void Airplane::setSeats(int seats){
    this->seats = seats;
}

void Airplane::setAvalibleSeats(int avalibleSeats){
    this->avalibleSeats = avalibleSeats;
}

void Airplane::landing(){
    cout << "The plane has landed" << endl;
 
    
}

void Airplane::taking_off(){
    cout << "The plane has taken off" << endl;
}





