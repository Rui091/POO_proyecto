#include <string>
#include <vector>
#include "gate.h"
#include "flight.h"
#include "aircraft.h"
#include <utility>
#include <map>


using namespace std;

#ifndef AIRTRAFFICCONTROLER_H
#define AIRTRAFFICCONTROLER_H

class AirTrafficControler{
    private:
        vector<Aircraft*> aircrafts;
        vector<Gate*> gates;
        map<int,int> airCraftLocations;

    public:
    //Constructor para el controlador de trafico aereo, recibe un vector de aeronaves y un vector de puertas
        AirTrafficControler();
        AirTrafficControler(vector<Aircraft*> aircrafts, vector<Gate*> gates);
    //getters y setters, adds y removes
        vector<Aircraft*> getAircrafts();
        vector<Gate*> getGates();
        void setVecGates(vector<Gate*> gates);
        void setVecAircrafts(vector<Aircraft*> aircrafts);
        void addAircraft(Aircraft *aircraft);
        void removeAircraft(int id);

    //La funcion permisson sirve para notificar a las aeronaves si tienen permiso 
    //para despegar o aterrizar, recibe un bool que es el permiso y 
    //un int que es el id de la aeronave, de esta forma la torre de control tiene el poder de decidir cuando es buen momento para que las aeronaves despeguen o aterricen
        void permisson(bool permisson, int id);

    //La funcion assingGate se encarga de asignar una puerta a un vuelo, recibe un vuelo y de esta forma se encarga de asignarle una puerta a ese vuelo
        void assingGate(Flight &flight);
    //La fundion notify se encarga de obtener todas las ubicaciones de las aeronaves, y de esta forma notificar a las demas aeronaves de las ubicaciones de todas las aeronaves que estan en el aire
        void notify();
        
        


};

#endif