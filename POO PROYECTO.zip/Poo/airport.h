#include <iostream>
#include <string>
#include <vector>
#include "passenger.h"
#include "crewmate.h"
#include "flight.h"
#include "aircraft.h"
#include "people.h"
#include "jet.h"
#include "helicopter.h"
#include "aircraftFactory.h"
#include "AirTrafficControler.h"
#include "gate.h"
#include "flight.h"
#include "Airline.h"


using namespace std;

#ifndef AIRPORT_H
#define AIRPORT_H


class Airport{
    private:
        string name;
        vector<Flight*> flights;
        vector<Aircraft*> aircrafts;
        vector<Gate*> gates;
        vector<Airline*> airlines;
        AirTrafficControler* atc;

    public:
    //Constructor para aeropuerto, que recibe solo el nombre
        Airport(string name);
    //getters y setters
        string getName();
        void setName(string name);
        vector<Flight*> getFlights();
        vector<Aircraft*> getAircrafts();
        vector<Gate*> getGates();
        vector<Airline*> getAirlines();
        AirTrafficControler* getAirTrafficControler();
        void addAircraft(Aircraft *aircraft);
        void addFlight(Flight *flight);
        void addAirline(Airline *airline);
        void setVecGates(vector<Gate*> gates);
        void setVecAircrafts(vector<Aircraft*> aircrafts);
        void setVecFlights(vector<Flight*> flights);
    //Metodos de la clase aeropuerto, que se encargan de crear los objetos como aeronaves y aerolineas, de esta forma el usuario tiene mas facilidad para usar el programa
        void createAircraft();
        void createAirline();
        void createGate();
        void createAirTrafficControler();
    //Metodo que se encarga de mostrar el menu principal, y de llamar a todos los metodos involucrados en el funcionamiento del programa
        void menu(vector<string> Destinations);


};

#endif