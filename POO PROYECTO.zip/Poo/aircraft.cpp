#include "aircraft.h"


Aircraft::Aircraft() {
    type_aircraft = "";
    brand = "";
    model = 0;
    capacity = 0;
    maxium_speed = 0;
    Autonomy = 0;
    Year_of_manufacture = 0;
    state = 0;
    location = 0;
    id = 0;
    flying = false;
}
Aircraft::Aircraft(const string& type_aircraft, const string& brand, int model,
             int capacity, int maxSpeed, int autonomy, int yearOfManufacture,
             int state,int location, int id, bool flying) {
    this->mapLocation = {};
    this->type_aircraft = type_aircraft;
    this->brand = brand;
    this->model = model;
    this->capacity = capacity;
    this->maxium_speed = maxSpeed;
    this->Autonomy = autonomy;
    this->Year_of_manufacture = yearOfManufacture;
    this->state = state;
    this->location = location;
    this->id = id;
    this->flying = flying;

}


string Aircraft::getType_aircraft(){
    return this->type_aircraft;
}


string Aircraft::getBrand() {
    return this->brand;
}
int Aircraft::getModel() {
    return this->model;
}
int Aircraft::getCapacity() {
    return this->capacity;
}
int Aircraft::getMaxium_speed() {
    return this->maxium_speed;
}
int Aircraft::getAutonomy() {
    return this->Autonomy;
}
int Aircraft::getYear_of_manufacture() {
    return this->Year_of_manufacture;
}
int Aircraft::getState() {
    return this->state;
}
int Aircraft::getLocation() {
    return this->location;
}
bool Aircraft::getFull_assigned() {
    bool ans;
    if(vec_flights.size() == 3){
        ans = false;
    }
    else if(vec_flights.size() < 3){
        ans = true;
    }
    return ans;
}

int Aircraft::getId() {
    return this->id;
}


bool Aircraft::getFlying() {
    return this->flying;
}

void Aircraft::setType(string type_aircraft) {
    this->type_aircraft = type_aircraft;
}
void Aircraft::setBrand(string brand) {
    this->brand = brand;
}

void Aircraft::setModel(int model) {
    this->model = model;
}

void Aircraft::setCapacity(int capacity) {
    this->capacity = capacity;
}

void Aircraft::setMaxium_speed(int maxium_speed) {
    this->maxium_speed = maxium_speed;
}

void Aircraft::setAutonomy(int Autonomy) {
    this->Autonomy = Autonomy;
}

void Aircraft::setYear_of_manufacture(int Year_of_manufacture) {
    this->Year_of_manufacture = Year_of_manufacture;
}

void Aircraft::setState(int state) {
    this->state = state;
}



void Aircraft::setLocation(int location) {
    this->location = location;
}


void Aircraft::setId(int id) {
    this->id = id;
}



void Aircraft::setFlying(const bool flying) {
    this->flying = flying;
}

void Aircraft::addFlight(Flight flight) {
    
    this->vec_flights.push_back(flight);
}



void Aircraft::landing() {
    cout << "Aircraft is landing" << endl;
}

void Aircraft::taking_off() {
    cout << "Aircraft is taking off" << endl;
}

void Aircraft::addVec_flights(Flight flights) {
    this->vec_flights = vec_flights;
}

int Aircraft::getvec_flights() {
    return vec_flights.size();
}


void Aircraft::update(map<int, int> mapLocation_atc) {
    
    mapLocation_atc.erase(this->id);
    this->mapLocation = mapLocation_atc;
    

}

void Aircraft::printLocation(){
    for (const auto& par : this->mapLocation) {
        std::cout << "ID: " << par.first << ", Altitud: " << par.second << std::endl;
    }
}

void Aircraft::printVec_flights() {
    for(int i=0;i<vec_flights.size();++i){
        cout<<"Airplane "<<this->getId()<<endl;
        cout<<"Origen: "<<vec_flights[i].getOrigen()<<endl;
        cout<<"Destino: "<<vec_flights[i].getDestiny()<<endl;
        cout<<"Fecha de salida: "<<vec_flights[i].getDepartureDate()<<endl;
        cout<<"Fecha de llegada: "<<vec_flights[i].getArrivalDate()<<endl;
        cout<<"ID: "<<vec_flights[i].getNumberFlight()<<endl;
        cout<<"--------------------------"<<endl;
    }
}

void Aircraft::updatePermission(bool permission) {
    if(flying == false && permission == true && this->getvec_flights() == 0){
        cout<<"Aicraft has no flights assigned"<<endl;
    }

    else if(flying == true && permission == true && this->getvec_flights() > 0 ){
        cout<<"Permission granted"<<endl;
        this->landing();
        this->flying = false;
    }
    else if(flying == false && permission == true){
        cout<<"Permission granted"<<endl;
        this->taking_off();

    }


    else if(permission == false){
        cout<<"Permission denied"<<endl;
    }
}