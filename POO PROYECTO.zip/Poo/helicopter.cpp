#include "helicopter.h"


int Helicopter::getRotors(){
    return rotors;
}



int Helicopter::getElevationCapacity(){
    return elevationCapacity;
}

int Helicopter::getUseType(){
    return useType;
}

void Helicopter::setRotors(int rotors){
    this->rotors = rotors;
}

void Helicopter::setElevationCapacity(int elevationCapacity){
    this->elevationCapacity = elevationCapacity;
}

void Helicopter::setUseType(int useType){
    this->useType = useType;
}

void Helicopter::landing() {
    cout << "The plane has landed" << endl;
}

void Helicopter::taking_off() {
    cout << "The plane has taken off" << endl;
}
