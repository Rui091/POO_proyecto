#include "people.h"
#include <iostream>
#include <string.h>


#ifndef PASSENGER_H
#define PASSENGER_H

using namespace std;

class Passenger:public People{
    protected:
        int numBags;
        string medical_info;
        string nationality;

    public:
    //constructores de passenger
        Passenger();
        Passenger(const std::string& name, int id, int number, const std::string& birth, const std::string& gender, const std::string& email,
              int numBags, const std::string& medical_info, const std::string& nationality);
    //getters y setters
        int getNumBags();
        string getMedicalInfo();
        string getNationality();
        void setNumBags(int numBags);
        void setMedicalInfo(string medical_info);
        void setNacionality(string nacionality);
    //Metodo para imprimir la informacion del pasajero
        void printInfo();


};

#endif