#include "flight.h"


Flight::Flight() {
    numberFlight = 0;
    Destiny = "";
    numberPassengers = 0;
    departureDate = "";
    arrivalDate = "";
    Origen = "";
}

Flight::Flight(int numberFlight, string Destiny, int numberPassengers, string departureDate, string arrivalDate, string Origen, vector <Passenger>flight_passengers,bool gateAsigned) {

   
    this->numberFlight = numberFlight;
    this->Destiny = Destiny;
    this->seats = numberPassengers;
    this->departureDate = departureDate;
    this->arrivalDate = arrivalDate;
    this->Origen = Origen;
    this->passengers = passengers;
    this->asignado = false;
    this->numberPassengers = this->passengers.size();
    this->gateAsigned = gateAsigned;

    

}

void Flight::printInfo(){
    cout << "Flight number: " << this->numberFlight << endl;
    cout << "Destination: " << this->Destiny << endl;
    cout << "Departure Date : " << this->departureDate << endl;
    cout << "Arrival Date: " << this->arrivalDate << endl;
    cout << "Origen: " << this->Origen << endl;
    cout << "Number of seats: " << this->seats << endl;
}

bool Flight::getAsignado() {
    return this->asignado;
}

void Flight::setAsignado(bool asignado) {
    this->asignado = asignado;
}

int Flight::getNumberFlight() {
    return this->numberFlight;
}

string Flight::getDestiny() {
    return this->Destiny;
}

int Flight::getNumberPassengers() {
    return this->passengers.size();
}

int Flight::getSeats() {
    return this->seats;
}

string Flight::getDepartureDate() {
    return this->departureDate;
}

string Flight::getArrivalDate() {
    return this->arrivalDate;
}

string Flight::getOrigen() {
    return this->Origen;
}

void Flight::setNumberFlight(int numberFlight) {
    this->numberFlight = numberFlight;
}

void Flight::setDestiny(string Destiny) {
    this->Destiny = Destiny;
}

void Flight::setNumberPassengers(int numberPassengers) {
    this->numberPassengers = numberPassengers;
}

void Flight::setDepartureDate(string departureDate) {
    this->departureDate = departureDate;
}

void Flight::setArrivalDate(string arrivalDate) {
    this->arrivalDate = arrivalDate;
}

void Flight::setOrigen(string Origen) {
    this->Origen = Origen;
}
/*
void Flight::setGate(Gate gate) {
    this->gate = gate;
}

Gate Flight::getGate() {
    return gate;
}
*/
void Flight::addPassenger(Passenger passenger) {
    passengers.push_back(passenger);
    this->seats -= 1;
    
}


vector<Passenger> Flight::getPassengers() {
    return passengers;
}


void Flight::addCrewmates(){
    Crewmate* pilot = new Crewmate("Andres",41,4532,"09/03/1976","male","ad67@gmail.com","pilot",7,10);
    Crewmate* assistant1 = new Crewmate("Sara",23,3433,"09/05/1976","female","ara7@gmail.com","assistant1",3,12);
    Crewmate* assistant2 = new Crewmate("valeria",21,4434,"09/08/1978","female","vake67@gmail.com","assistant2",2,12);
    Crewmate* assistant3 = new Crewmate("karen",32,4333,"13/10/2000","male","karen@gmail.com","assistant",1,6);

    crewmates.push_back(*pilot);
    crewmates.push_back(*assistant1);
    crewmates.push_back(*assistant2);
    crewmates.push_back(*assistant3);

    delete pilot;
    delete assistant1;
    delete assistant2;
    delete assistant3;
    
}

void Flight::setgate(bool gateAsigned1){
    this->gateAsigned = gateAsigned1;
}

bool Flight::getGateAsigned(){
    return this->gateAsigned;
}






