#include "aircraft.h"
#include "airplane.h"
#include "helicopter.h"
#include "jet.h"

using namespace std;

#ifndef AIRCRAFTFACTORY_H
#define AIRCRAFTFACTORY_H

/**
 * @brief Clase que representa una fábrica de aeronaves.
 */
class AircraftFactory {
public:
    /**
     * @brief Crea una instancia de avión (Airplane).
     * @param brand Marca del avión.
     * @param model Modelo del avión.
     * @param capacity Capacidad de pasajeros.
     * @param maxSpeed Velocidad máxima.
     * @param autonomy Autonomía de vuelo.
     * @param yearOfManufacture Año de fabricación.
     * @param state Estado del avión.
     * @param maxAltitude Altitud máxima de vuelo.
     * @param numEngines Número de motores del avión.
     * @param category Categoría del avión.
     * @param location Ubicación del avión.
     * @param id Identificador único del avión.
     * @param flying Indica si el avión está volando.
     * @param seats Número total de asientos del avión.
     * @param availableSeats Número de asientos disponibles en el avión.
     * @return Puntero a la instancia de avión creada.
     */
    static Aircraft* createAirplane(const std::string& brand, int model, int capacity,
                                    int maxSpeed, int autonomy, int yearOfManufacture,
                                    int state, int maxAltitude, int numEngines, int category,
                                    int location, int id, bool flying, int seats, int availableSeats);

    /**
     * @brief Crea una instancia de helicóptero (Helicopter).
     * @param brand Marca del helicóptero.
     * @param model Modelo del helicóptero.
     * @param capacity Capacidad de pasajeros.
     * @param maxSpeed Velocidad máxima.
     * @param autonomy Autonomía de vuelo.
     * @param yearOfManufacture Año de fabricación.
     * @param state Estado del helicóptero.
     * @param location Ubicación del helicóptero.
     * @param id Identificador único del helicóptero.
     * @param flying Indica si el helicóptero está volando.
     * @param rotors Número de rotores del helicóptero.
     * @param elevationCapacity Capacidad de elevación del helicóptero.
     * @param useType Tipo de uso del helicóptero.
     * @return Puntero a la instancia de helicóptero creada.
     */
    static Aircraft* createHelicopter(const string& brand, int model, int capacity,
                                      int maxSpeed, int autonomy, int yearOfManufacture,
                                      int state, int location, int id, bool flying,
                                      int rotors, int elevationCapacity, int useType);

    /**
     * @brief Crea una instancia de jet (Jet).
     * @param brand Marca del jet.
     * @param model Modelo del jet.
     * @param capacity Capacidad de pasajeros.
     * @param maxSpeed Velocidad máxima.
     * @param autonomy Autonomía de vuelo.
     * @param yearOfManufacture Año de fabricación.
     * @param state Estado del jet.
     * @param location Ubicación del jet.
     * @param id Identificador único del jet.
     * @param flying Indica si el jet está volando.
     * @param owner Propietario del jet.
     * @param services Servicios disponibles en el jet.
     * @param destinies Destinos disponibles para el jet.
     * @return Puntero a la instancia de jet creada.
     */
    static Aircraft* createJet(const string& brand, int model, int capacity,
                               int maxSpeed, int autonomy, int yearOfManufacture,
                               int state, int location, int id, bool flying,
                               const string& owner, const vector<string>& services,
                               const vector<string>& destinies);
};

#endif