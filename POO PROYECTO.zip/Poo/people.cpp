#include "people.h"


People::People(){
    id = 0;
    name = "";
    number = 0;
    email = "";
    birth = "";
    gender = "";    
}

People:: People(string name, int id, int number, string birth, string gender, string email){
    this->name = name;
    this->id = id;
    this->number = number;
    this->birth = birth;
    this->gender = gender;
    this->email = email;


}

string People::getName(){
    return name;
}

int People::getId(){
    return id;
}

int People::getNumber(){
    return number;
}

string People::getBirth(){
    return birth;
}

string People::getEmail(){
    return email;
}

string People::getGender(){
    return gender;
}

void People::setName(string name){
    this->name = name;
}

void People::setId(int id){
    this->id = id;
}

void People::setNumber(int number){
    this->number = number;
}

void People::setBirth(string birth){
    this->birth = birth;
}

void People::setEmail(string email){
    this->email = email;
}

void People::setGender(string gender){
    this->gender = gender;
}
