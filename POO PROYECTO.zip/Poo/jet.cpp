#include "jet.h"

string Jet::getOwner(){
    return owner;
}


vector <string> Jet::getServices(){
    return services;
}

vector <string> Jet::getDestinies(){
    return destinies;
}

void Jet::setOwner(string owner){
    this->owner = owner;
}

void Jet::addService(string service){
    this->services.push_back(service);
}

void Jet::addDestiny(string destiny){
    this->destinies.push_back(destiny);
}

void Jet::landing(){
    cout << "The jet is landing" << endl;
}

void Jet::taking_off(){
    cout << "The jet is taking off" << endl;
    
}